//
//  AppDelegate.swift
//  FindWay_varshini_779380
//
//  Created by Valliveti Vidya Jayakumar on 2020-06-13.
//  Copyright © 2020 Valliveti Vidya Jayakumar. All rights reserved.
//

import UIKit
import SwiftyUserDefaults

var g_places:[PlaceModel] = []
var g_ids:[Int]   = []
var g_names:[String] = []
var g_lats:[Double]  = []
var g_lons:[Double]  = []

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        g_ids = Defaults[\.placeIds] ?? [Int]()
        g_names = Defaults[\.placeNames] ?? [String]()
        g_lats = Defaults[\.placeLats] ?? [Double]()
        g_lons = Defaults[\.placeLons] ?? [Double]()
        
        for index in 0 ..< g_ids.count {
            let place = PlaceModel()
            
            place.id   = g_ids[index]
            place.name = g_names[index]
            place.lat  = g_lats[index]
            place.lon  = g_lons[index]
            
            g_places.append(place)
        }
        
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }


}

