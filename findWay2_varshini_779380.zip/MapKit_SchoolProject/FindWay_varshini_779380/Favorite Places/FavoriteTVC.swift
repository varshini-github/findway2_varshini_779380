//
//  FavoriteTVC.swift
//

import UIKit
import SwiftyUserDefaults

class FavoriteTVC: UITableViewController {

    var myDataSource:[PlaceModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tableView.tableFooterView = UIView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        getPlaces()
    }
    
    fileprivate func getPlaces() {
        
        myDataSource = g_places
        self.tableView.reloadData()
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return myDataSource.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PlaceCell", for: indexPath) as! PlaceCell

        cell.placeNameLabel.text = myDataSource[indexPath.row].name

        return cell
    }

    // delete table row
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let index = indexPath.row
            // Delete the row from the data source
            self.myDataSource.remove(at: index)
            
            removePlace(index: index)
            // Delete the row from the TableView
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    
    fileprivate func removePlace(index: Int) {
        g_places.remove(at: index)
        
        g_ids.remove(at: index)
        g_names.remove(at: index)
        g_lats.remove(at: index)
        g_lons.remove(at: index)
        
        Defaults[\.placeIds] = g_ids
        Defaults[\.placeNames] = g_names
        Defaults[\.placeLats] = g_lats
        Defaults[\.placeLons] = g_lons
    }

    // cell
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tableView.deselectRow(at: indexPath, animated: true)
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MapVC") as! MapVC
        vc.myPlace = myDataSource[indexPath.row]
        vc.editPlace = true
        vc.currentIndex = indexPath.row
        navigationController?.pushViewController(vc, animated: true)
    }
    
}
