//
//  PlaceModel.swift
//

import Foundation

class PlaceModel: Codable {
    var id: Int = 0
    var name: String = ""
    var lat: Double = 0.0
    var lon: Double = 0.0
}
