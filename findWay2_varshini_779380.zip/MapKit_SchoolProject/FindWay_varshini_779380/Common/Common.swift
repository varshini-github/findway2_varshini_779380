//
//  Common.swift
//

import UIKit
import SwiftyUserDefaults

final class Common: NSObject {
  
    static let shared = Common()
    
    
    func getCurrentTimestamp() -> Int64 {
        return Int64(Date().timeIntervalSince1970)
    }
    
}


extension DefaultsKeys {
    // for user model
    var placeIds:            DefaultsKey<Array<Int>?> { .init("placeIds", defaultValue: []) }
    var placeNames:          DefaultsKey<Array<String>?> { .init("placeNames", defaultValue: []) }
    var placeLats:           DefaultsKey<Array<Double>?> { .init("placeLats", defaultValue: []) }
    var placeLons:           DefaultsKey<Array<Double>?> { .init("placeLons", defaultValue: []) }
}
